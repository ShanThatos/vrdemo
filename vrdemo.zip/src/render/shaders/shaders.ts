/* eslint-disable @typescript-eslint/ban-ts-comment */
// @ts-nocheck


export { default as VS_verts } from "./shadercode/VS_verts.vert";
export { default as FS_generic } from "./shadercode/FS_generic.frag";

export const NUM_LIGHTS = 5;